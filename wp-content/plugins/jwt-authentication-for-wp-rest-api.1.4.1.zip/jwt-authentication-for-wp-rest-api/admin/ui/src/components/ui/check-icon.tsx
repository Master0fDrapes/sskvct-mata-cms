import { CheckCircle } from 'lucide-react'

export const Check = () => <CheckCircle className="jwt-h-5 jwt-w-5 jwt-text-emerald-500" />
